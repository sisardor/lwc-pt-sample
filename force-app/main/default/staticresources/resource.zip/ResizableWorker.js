﻿// this file is intended to instruct PDFworker to wait until
// size information has been received before loading PDFNetC.js
self.shouldResize = true;
importScripts('PDFworker.js');